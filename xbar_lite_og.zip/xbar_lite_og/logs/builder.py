# 2025-03-08T17:28:21.258293900
import vitis

client = vitis.create_client()
client.set_workspace(path="D:/mtp_prblm_new/xbar_lite_og")

vitis.dispose()

